# trading_bot package initialization
